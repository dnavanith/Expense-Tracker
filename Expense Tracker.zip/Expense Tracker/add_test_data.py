import sqlite3

def connect_db():
    return sqlite3.connect('expenses.db')

def add_test_data():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO expenses (date, category, amount, description) VALUES (?, ?, ?, ?)',
                   ('2024-08-01', 'Groceries', 50.75, 'Weekly groceries'))
    cursor.execute('INSERT INTO expenses (date, category, amount, description) VALUES (?, ?, ?, ?)',
                   ('2024-08-01', 'Transportation', 15.00, 'Bus fare'))
    cursor.execute('INSERT INTO expenses (date, category, amount, description) VALUES (?, ?, ?, ?)',
                   ('2024-08-01', 'Entertainment', 20.00, 'Movie ticket'))
    conn.commit()
    conn.close()

add_test_data()
