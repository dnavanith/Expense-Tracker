document.getElementById('expense-form').addEventListener('submit', addExpense);

async function addExpense(e) {
    e.preventDefault();
    const date = document.getElementById('date').value;
    const category = document.getElementById('category').value;
    const amount = document.getElementById('amount').value;
    const description = document.getElementById('description').value;

    const response = await fetch('/add', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ date, category, amount, description })
    });

    const result = await response.json();
    if (result.status === 'success') {
        fetchExpenses();
    }
}

async function fetchExpenses() {
    const response = await fetch('/expenses');
    const expenses = await response.json();
    const expenseList = document.getElementById('expense-list');
    expenseList.innerHTML = '';
    expenses.forEach(expense => {
        const expenseItem = document.createElement('div');
        expenseItem.textContent = `${expense[1]} - ${expense[2]} - $${expense[3]} - ${expense[4]}`;
        expenseList.appendChild(expenseItem);
    });
}

fetchExpenses();
