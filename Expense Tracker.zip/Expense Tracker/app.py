from flask import Flask, request, jsonify, render_template
import sqlite3

app = Flask(__name__)

def connect_db():
    return sqlite3.connect('expenses.db')

def create_table():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY,
        date TEXT,
        category TEXT,
        amount REAL,
        description TEXT
    )
    ''')
    conn.commit()
    conn.close()

# Flag to ensure the table is created only once
table_created = False

@app.before_request
def initialize():
    global table_created
    if not table_created:
        create_table()
        table_created = True

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/add', methods=['POST'])
def add_expense():
    data = request.json
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO expenses (date, category, amount, description) VALUES (?, ?, ?, ?)',
                   (data['date'], data['category'], data['amount'], data['description']))
    conn.commit()
    print(f"Inserted data: {data}")  # Debugging statement
    conn.close()
    return jsonify({'status': 'success'})


@app.route('/expenses', methods=['GET'])
def get_expenses():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM expenses')
    expenses = cursor.fetchall()
    conn.close()
    return jsonify(expenses)

if __name__ == '__main__':
    app.run(debug=True)
